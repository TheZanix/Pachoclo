"use client"

import { motion } from "framer-motion"
import { useEffect, useState, useRef } from "react"

export default function Home() {
  const [showConfetti, setShowConfetti] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  }

  const listItemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.5, ease: "easeOut" } },
  }

  // Scroll detection for confetti
  useEffect(() => {
    const handleScroll = () => {
      // Trigger confetti when scrolled near the bottom (e.g., last 100px)
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 100) {
        if (!showConfetti) {
          setShowConfetti(true)
          // Hide confetti after a few seconds
          setTimeout(() => {
            setShowConfetti(false)
          }, 3000) // Confetti visible for 3 seconds
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [showConfetti])

  const playSound = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0 // Reset to start
      audioRef.current.play().catch((e) => console.error("Error playing sound:", e))
    }
  }

  const stopSound = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0 // Reset to start
    }
  }

  return (
    <div className="main-wrapper">
      <motion.header initial="hidden" animate="visible" variants={containerVariants} transition={{ delay: 0.2 }}>
        <motion.h1 variants={containerVariants}>{"🎉 ¡Estás invitado a Pachoclo's Comedy! 🎉"}</motion.h1>
        <motion.h2 variants={containerVariants} transition={{ delay: 0.4 }}>
          {"Una noche de risas y diversión patrocinada por el multimillonario Pachoclo🐍"}
        </motion.h2>
      </motion.header>

      <motion.div
        className="event-details"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        variants={containerVariants}
        transition={{ delay: 0.6 }}
      >
        <p>
          <strong>📅 Fecha:</strong> [Todos los domingos]
        </p>
        <p>
          <strong>🕒 Hora:</strong> [17:00] hasta (21:00)
        </p>
        <p>
          <strong>🌍 Servidor Java:</strong>
        </p>
        <p>
          <strong>🔗 IP (Java):</strong> [25.ip.gl.ply.gg:18916]
        </p>
        <p>
          <strong>🌐 Puerto (Java):</strong> [18916]
        </p>
        <p>
          <strong>🐍 Version Servidor:</strong> 1.21.4
        </p>
        <p>
          <strong>🌍 Servidor Bedrock:</strong>
        </p>
        <p>
          <strong>🔗 IP (Bedrock):</strong> [A Futuro]
        </p>
        <p>
          <strong>🌐 Puerto (Bedrock):</strong> [A Futuro]
        </p>
      </motion.div>

      <motion.h2
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
        variants={containerVariants}
        transition={{ delay: 0.8 }}
      >
        {"¿Qué esperar?"}
      </motion.h2>
      <motion.ul
        className="animated-list"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
        transition={{ staggerChildren: 0.2, delayChildren: 1.0 }}
      >
        <motion.li variants={listItemVariants}>🎤 Comediantes.</motion.li>
        <motion.li variants={listItemVariants}>🦌 Nokotans.</motion.li>
        <motion.li variants={listItemVariants}>🚽😁 Skibidis</motion.li>
      </motion.ul>

      <motion.h1
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
        variants={containerVariants}
        transition={{ delay: 1.6 }}
      >
        {"😂 ¡Tú también puedes participar! Trae tus mejores chistes y cuéntalos en el escenario."}
      </motion.h1>
      <motion.a
        href="https://discord.com/invite/kcwSEE7ext"
        className="cta"
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1, transition: { delay: 1.8, duration: 0.5 } }}
        viewport={{ once: true, amount: 0.5 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onMouseEnter={playSound}
        onMouseLeave={stopSound}
      >
        {"yo ya estoy! 🗣️"}
      </motion.a>

      <motion.footer
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
        variants={containerVariants}
        transition={{ delay: 2.0 }}
      >
        Invita a tus amigos y prepárate para una noche inolvidable. ¡Te esperamos en Pachoclo's Comedy!
      </motion.footer>

      {/* Audio element for the button sound */}
      <audio ref={audioRef} src="https://www.myinstants.com/media/sounds/yo-ya-estoy.mp3" preload="auto" />

      {/* Confetti animation */}
      {showConfetti && (
        <div className="confetti-container">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="confetti-piece"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                backgroundColor: `hsl(${Math.random() * 360}, 70%, 60%)`,
                transform: `rotate(${Math.random() * 360}deg)`,
              }}
            />
          ))}
        </div>
      )}

      <style jsx global>{`
        /* Estilos globales */
        body {
          font-family: 'Comic Sans MS', 'Arial', sans-serif; /* Fuente más juguetona */
          background-color: #f0f8ff;
          color: #333;
          margin: 0;
          padding: 20px;
          text-align: center;
          box-sizing: border-box;
          overflow-x: hidden; /* Evita el scroll horizontal por animaciones */
        }
        /* Fondo de confeti */
        body::before {
          content: '';
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: repeating-linear-gradient(
            45deg,
            #ff634720,
            #ff634720 10px,
            #4682b420 10px,
            #4682b420 20px
          );
          opacity: 0.1;
          z-index: -1;
          animation: confetti-move 60s linear infinite;
        }

        @keyframes confetti-move {
          from { background-position: 0 0; }
          to { background-position: 1000px 1000px; }
        }
      `}</style>

      <style jsx>{`
        /* Estilos específicos del componente */
        .main-wrapper {
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }

        h1 {
            color: #ff6347;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2); /* Sombra de texto para un mejor contraste */
        }

        h2 {
            color: #4682b4;
        }

        .event-details {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15); /* Sombra de caja mejorada */
            margin: 20px 0;
        }

        ul {
          list-style: none; /* Elimina los puntos de lista predeterminados */
          padding: 0;
          margin: 20px 0;
        }
        li {
          margin-bottom: 10px;
        }

        .cta {
            font-size: 1.2em;
            background-color: #ff6347;
            color: white;
            padding: 12px 25px; /* Relleno ligeramente mayor */
            border-radius: 5px;
            text-decoration: none;
            display: inline-block; /* Necesario para que transform funcione */
            margin-top: 20px;
        }
        .cta:hover {
            background-color: #ff4500;
        }

        /* Confetti Styles */
        .confetti-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          overflow: hidden;
          z-index: 9999;
        }

        .confetti-piece {
          position: absolute;
          width: 10px;
          height: 10px;
          background-color: #f00; /* Default color, overridden by inline style */
          opacity: 0;
          animation: confetti-fall 3s forwards;
        }

        @keyframes confetti-fall {
          0% {
            transform: translateY(-100vh) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  )
}
